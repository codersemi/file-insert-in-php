


<?php
include ("db.php");

$query   = "SELECT * FROM record";
$data    = mysqli_query($conn,$query);
$total   = mysqli_num_rows($data);

if($total !=0){
    // echo "Correct";
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="table.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>

<div class="mykhata">
    <h2>My Image </h2>
 
   
</div>

<table>
    <tr>
        <th id='thdr'>ID</th>
        <th id='thdr'>Photo</th>
        <th id='thdr'>Name</th>
        <th id='thdr'>Address</th>
        <th id='thdr'>Conatct</th>
        <th id='act' colspan="2">Action</th>
    </tr>
</html>

<?php
while($result = mysqli_fetch_assoc($data))
{
echo "<tr>
          <td>".$result['id']."</td>

          <td><img src='".$result['photo']."' height='40px' width='40px'></td>
          <td>".$result['name']."</td>
          <td>".$result['address']."</td>
          <td>".$result['contact']."</td>
        
          <td id='action'><a href='update.php?id=$result[id]'>Update</a></td>
          <td id='action'><a href='delete.php?id=$result[id]'  onclick='return del();'>Delete</a></td>
          
      </tr>";
}

}else{
    echo "<h1>No More Data</h1>";
}

?>
</table>


<script>
    

    function del(){            
        return confirm("Are you want to sure delete ?");
    }
 </script>
    
