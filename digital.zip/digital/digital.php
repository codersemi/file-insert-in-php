


<?php
include ("db.php");
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="digital.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>digital-data</title>
</head>
<body>
    <div class="cotainer">
        <form method="post" autocomplete="off" enctype="multipart/form-data">
            <fieldset>
                <legend><h2>Digital Contact Info Form</h2></legend>

            <input type="file"   name="photo" class="input" required><br>
            <input type="text"   name="name" class="input" placeholder="Full Name" required><br>
            <input type="text"   name="address" class="input" placeholder="Address" required><br>
            <input type="number" name="contact" class="input" placeholder="Phone Number" required><br>
            <input type="submit" name="save" value="Save" class="enter"><br>
            <input type="reset" value="Reset" class="reset"><br>
            </fieldset>
        </form>

    </div>
</body>
</html>


<!-- this line below PHP CODE for insert the data into database  -->
<?php
if($_POST['save']){
  

    // this line below code is just for insert image file into the database

    $filename    = $_FILES['photo']['name'];
    $tempname    = $_FILES['photo']['tmp_name'];
    $folder      = "gallery/".$filename;
    move_uploaded_file($tempname,$folder);


    // end this line below code is just for insert image file into the database


    $photo  = $_POST['photo'];
    $name     = $_POST['name'];
    $address  = $_POST['address'];
    $contact  = $_POST['contact'];

  $query = "INSERT INTO record (photo,name,address,contact)VALUES('$folder','$name','$address','$contact')";
  $data  = mysqli_query($conn,$query);

  if($data){
    echo "<script> alert('Data has been inserted') </script>";
  }else{
    echo "Not inserted";
  }
}
?>

<!-- end this line below PHP CODE for insert the data into database  -->