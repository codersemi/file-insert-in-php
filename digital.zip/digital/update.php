

<?php
include ("db.php");
$id  = $_GET['id'];

$query  = "SELECT * FROM record WHERE id='$id'";
$data   = mysqli_query($conn,$query);
// $total  = mysqli_num_row($data);
$result = mysqli_fetch_assoc($data);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="digital.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>digital-data-update</title>
</head>
<body>
    <div class="cotainer">
        <form method="post" autocomplete="off" enctype="multipart/form-data">
            <fieldset>
                <legend><h2>Digital Data Update Form</h2></legend>

            <input type="file"   value="<?php echo $result['photo'];?>"   name="photo" class="input" required><br>
            <input type="text"   value="<?php echo $result['name'];?>"  name="name" class="input" placeholder="Full Name" required><br>
            <input type="text"   value="<?php echo $result['address'];?>"  name="address" class="input" placeholder="Address" required><br>
            <input type="number" value="<?php echo $result['contact'];?>" name="contact" class="input" placeholder="Phone Number" required><br>
            <input type="submit" name="save" value="Update" class="enter"><br>
            <input type="reset" value="Reset" class="reset"><br>
            </fieldset>
        </form>

    </div>
</body>
</html>




<?php
if($_POST['save']){
  
    // this line below code is just for insert image file into the database

    $filename    = $_FILES['photo']['name'];
    $tempname    = $_FILES['photo']['tmp_name'];
    $folder      = "gallery/".$filename;
    move_uploaded_file($tempname, $filename);


    // end this line below code is just for insert image file into the database


    $photo    = $_POST['photo'];
    $name     = $_POST['name'];
    $address  = $_POST['address'];
    $contact  = $_POST['contact'];

    $query = "UPDATE record SET photo='$folder', name='$name', address='$address', contact='$contact' WHERE id='$id'";
    $data  = mysqli_query($conn,$query);
    if($data){
        echo "<script> alert('Data has been update.')</script>";
        ?>

<meta http-equiv ="refresh" content="0; url = http://localhost/digital/gtable.php"/>

        <?php

    }else{
        echo "Not Updated";
    }
}
?>

<!-- end this line below PHP CODE for insert the data into database  -->
















