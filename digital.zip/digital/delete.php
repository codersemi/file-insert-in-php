<?php
include ("db.php");
$id = $_GET['id'];

$query = "DELETE FROM record WHERE id='$id'";
$data  = mysqli_query($conn,$query);

if($data){
    echo "Deleted has been deleted";
    ?>
    <meta http-equiv ="refresh" content="1; url = http://localhost/digital/gtable.php"/>
    <?php
}else{
    echo "Not Now";
}

?>