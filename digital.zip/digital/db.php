<?php
error_reporting(0);

$servername    = "localhost";
$user          = "root";
$pass          = "";
$dbname        = "digital";

$conn = mysqli_connect($servername,$user,$pass,$dbname);

if($conn){
    // echo  "Activate";
}else{
    echo "Not Activate";
}

?>